package com.example.backend.repository;

import com.example.backend.entity.TeacherSlot;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TeacherSlotRepository extends JpaRepository<TeacherSlot,Integer> {
}
